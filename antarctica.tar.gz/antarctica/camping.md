# Precautions

- camp away from water and cook area hidden from view
- clean up trash, pack it out, use the sump, leave what you find
- respect wildlife, never provoke a bear
- store fuel, smellables, food in hung bear bag at night
- build structures well and for great reasons

# Essentials

1. map and compass, plan and prepare
2. sun and insect protection
3. matches, minimize campfire impact
4. first aid kit, 
5. rain gear & extra layered clothing
6. water bottles filled with disinfected water
7. tell someone your itinerary, be kind
8. extra food
9. pocket knife, leave what you find
10. watch, be considerate of other visitors

