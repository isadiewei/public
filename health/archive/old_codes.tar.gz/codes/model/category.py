# idk another wrapper or something
class MoveToAnotherFileAndRename:
    def __init__(self):
        self.mebomebo = (2, 0)

class Word:
    def __init__(self, html_type):
        self.type = html_type

    def initialize_content(self, content):
        self.content = content
        # process content
        # find page connections
        self.definitions = [] # for adding mebos
        # find external connections
