from nltk.tokenize import sent_tokenize, word_tokenize
# these have ridiculous names due to conflicting with python libraries
# and not feeling like using namespaces right now

class Dicitonizor:
    def __init__(self):
        self.dictionary = {}

# it is a dictionary how wonderful now abandon it and appreviate the amount of fucks you give
